# Welcome to VST 3 SDK public_sdk

Here are located:

- helper classes implementing VST3 Interfaces
- samples of VST3 Hosting and VST3 Plug-Ins
- AAX Wrapper
- AU Wrapper
- AUv3 Wrapper
- VST2 Wrapper
- InterAppAudio

## License & Usage guidelines

More details are found at [VST 3 SDK public_sdk License](https://forums.steinberg.net/t/vst-3-sdk-public-sdk-license/695592)

----
Return to [VST 3 SDK](https://github.com/steinbergmedia/vst3sdk)