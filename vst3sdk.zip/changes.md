# Changes to actual content that were made:

- Documentation website and SDK samples were removed for the sake of slimming the repo
`$ rm -rf doc vstgui4 public.sdk/samples`

This is a proper CMake installable VST3 3.7.3 and works with `vcpkg`